
SPA Datasheets October 2023 - JavaScript Object Notation (JSON) Format Data
---------------------------------------------------------------------------

JSON data extracted from the SPA Dataseheet Excel Spreadsheet:

	SPA_datasheets_October_2023.xlsx


Four JSON files were created from the following Excel worksheets:

	1. Sites - exported JSON file: SPA_datasheets_October_2023_Site_Data.json
	2. Site Mapping - exported JSON file: SPA_datasheets_October_2023_Site_Mapping_Data.json
	3. Bird SCIs- exported JSON file: SPA_datasheets_October_2023_Bird_SCI_Data.json
	4. Wetland SCIs - exported JSON file: SPA_datasheets_October_2023_Wetland_SCI_Data.json


E. Wymer
17/10/2023