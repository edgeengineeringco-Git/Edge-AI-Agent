
SPA Datasheets October 2023 - Comma Separated Value (CSV) Format Data
---------------------------------------------------------------------

CSV data extracted from the SPA Dataseheet Excel Spreadsheet:

	SPA_datasheets_October_2023.xlsx


Four CSV files were created from the following Excel worksheets:

	1. Sites - exported CSV file: SPA_datasheets_October_2023_Site_Data.csv
	2. Site Mapping - exported CSV file: SPA_datasheets_October_2023_Site_Mapping_Data.csv
	3. Bird SCIs- exported CSV file: SPA_datasheets_October_2023_Bird_SCI_Data.csv
	4. Wetland SCIs - exported CSV file: SPA_datasheets_October_2023_Wetland_SCI_Data.csv


E. Wymer
17/10/2023