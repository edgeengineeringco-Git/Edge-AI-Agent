
SAC Datasheets October 2023 - Comma Separated Value (CSV) Format Data
---------------------------------------------------------------------

CSV data extracted from the SAC Datasheet Excel Spreadsheet:

	SAC_datasheets_October_2023.xlsx


Four CSV files were created from the following Excel worksheets:

	1. Sites - exported CSV file: SAC_datasheets_October_2023_Site_Data.csv
	2. Site Mapping - exported CSV file: SAC_datasheets_October_2023_Site_Mapping_Data.csv
	3. Habitats - exported CSV file: SAC_datasheets_October_2023_Habitat_Data.csv
	4. Species - exported CSV file: SAC_datasheets_October_2023_Species_Data.csv


E. Wymer
17/10/2023