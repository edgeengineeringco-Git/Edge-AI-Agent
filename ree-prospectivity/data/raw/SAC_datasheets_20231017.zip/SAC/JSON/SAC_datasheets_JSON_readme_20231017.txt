
SAC Datasheets October 2023 - JavaScript Object Notation (JSON) Format Data
---------------------------------------------------------------------------

JSON data extracted from the SAC Dataseheet Excel Spreadsheet:

	SAC_datasheets_October_2023.xlsx

Four JSON files were created from the following Excel worksheets:

	1. Sites - exported JSON file: SAC_datasheets_October_2023_Site_Data.json
	2. Site Mapping - exported JSON file: SAC_datasheets_October_2023_Site_Mapping_Data.json
	3. Habitats - exported JSON file: SAC_datasheets_October_2023_Habitat_Data.json
	4. Species - exported JSON file: SAC_datasheets_October_2023_Species_Data.json

E. Wymer
17/10/2023